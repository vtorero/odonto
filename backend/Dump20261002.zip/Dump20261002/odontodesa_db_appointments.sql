-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `appointment_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `duration` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dental_chair` int DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('scheduled','confirmed','in_waiting','in_progress','completed','cancelled','no_show') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'scheduled',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_appt_patient` (`patient_id`),
  KEY `fk_appt_doctor` (`doctor_id`),
  CONSTRAINT `fk_appt_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_appt_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,1,2,'2026-10-01','09:45:00','10:15:00','45',1,'555','completed','prueba','2026-10-01 02:46:15','2026-10-01 19:19:00'),(8,2,2,'2026-10-01','12:00:00','12:30:00','45',1,'555','completed','wwww','2026-10-01 04:35:27','2026-10-01 16:19:59'),(9,1,2,'2026-09-30','13:00:00','13:30:00','45',1,'555','in_waiting','55555','2026-10-01 04:49:37','2026-10-01 23:49:57'),(13,3,2,'2026-10-02','10:45:00','11:30:00',NULL,2,'','completed','','2026-10-01 16:40:30','2026-10-01 23:50:10'),(16,1,2,'2026-10-01','11:00:00','11:30:00',NULL,3,'','completed','','2026-10-01 16:57:52','2026-10-01 23:49:30'),(27,3,1,'2026-10-01','12:30:00','13:00:00',NULL,1,'5555','completed','444','2026-10-01 17:36:23','2026-10-01 23:51:07'),(28,2,1,'2026-10-01','13:00:00','13:30:00',NULL,1,'','completed','','2026-10-01 17:38:17','2026-10-02 05:15:19'),(29,2,1,'2026-10-02','11:30:00','12:00:00',NULL,1,'','completed','','2026-10-01 18:00:57','2026-10-01 23:46:53'),(30,2,1,'2026-10-02','10:30:00','11:00:00',NULL,1,'','completed','','2026-10-02 14:38:02','2026-10-02 14:47:57'),(31,2,1,'2026-10-04','08:30:00','09:00:00',NULL,1,'','scheduled','','2026-10-02 14:46:17','2026-10-02 14:46:17'),(32,3,1,'2026-10-04','09:00:00','09:30:00',NULL,1,'','scheduled','','2026-10-02 14:48:30','2026-10-02 14:48:30'),(33,2,1,'2026-10-04','09:30:00','10:30:00',NULL,1,'prueba de motivo','scheduled','','2026-10-02 14:51:10','2026-10-02 14:51:10');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-02 16:44:59
