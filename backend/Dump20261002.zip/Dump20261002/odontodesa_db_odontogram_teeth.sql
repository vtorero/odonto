-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `odontogram_teeth`
--

DROP TABLE IF EXISTS `odontogram_teeth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `odontogram_teeth` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `tooth_number` int NOT NULL,
  `data_json` longtext COLLATE utf8mb4_unicode_ci,
  `whole_condition` enum('healthy','caries','restored','endodontics','crown','extraction_needed','absent','implant','orthodontics') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'healthy',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` int DEFAULT '1',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_patient_tooth` (`patient_id`,`tooth_number`),
  CONSTRAINT `fk_odo_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `odontogram_teeth`
--

LOCK TABLES `odontogram_teeth` WRITE;
/*!40000 ALTER TABLE `odontogram_teeth` DISABLE KEYS */;
INSERT INTO `odontogram_teeth` VALUES (4,2,0,'{\"11\":{\"toothNumber\":11,\"surfaces\":{\"center\":\"caries\",\"top\":\"caries\"},\"lastUpdated\":\"2026-09-23T17:51:40.028Z\",\"notes\":\"Cemento\",\"wholeToothCondition\":\"caries\"},\"13\":{\"toothNumber\":13,\"surfaces\":{\"right\":\"extraction_needed\"},\"lastUpdated\":\"2026-09-23T17:26:10.902Z\"},\"21\":{\"toothNumber\":21,\"surfaces\":{\"right\":\"caries\"},\"lastUpdated\":\"2026-09-22T20:26:08.684Z\"},\"22\":{\"toothNumber\":22,\"surfaces\":[],\"wholeToothCondition\":\"caries\",\"lastUpdated\":\"2026-09-23T17:49:49.120Z\"},\"23\":{\"toothNumber\":23,\"surfaces\":{\"center\":\"caries\"},\"lastUpdated\":\"2026-09-23T17:45:03.068Z\",\"wholeToothCondition\":\"caries\"},\"24\":{\"toothNumber\":24,\"surfaces\":{\"center\":\"caries\"},\"wholeToothCondition\":\"crown\",\"lastUpdated\":\"2026-09-23T18:03:13.257Z\"},\"43\":{\"toothNumber\":43,\"surfaces\":[],\"notes\":\"\",\"lastUpdated\":\"2026-09-22T20:25:16.300Z\"},\"52\":{\"toothNumber\":52,\"surfaces\":[],\"wholeToothCondition\":\"caries\",\"lastUpdated\":\"2026-09-22T20:32:31.132Z\"},\"61\":{\"toothNumber\":61,\"surfaces\":[],\"wholeToothCondition\":\"restored\",\"lastUpdated\":\"2026-09-22T20:32:33.813Z\"},\"62\":{\"toothNumber\":62,\"surfaces\":[],\"wholeToothCondition\":\"caries\",\"lastUpdated\":\"2026-09-23T18:02:20.497Z\"}}','healthy',NULL,77,'2026-09-23 18:03:13','2026-09-23 18:03:13'),(5,1,0,'{\"11\":{\"toothNumber\":11,\"surfaces\":{\"center\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:46:59.667Z\"},\"12\":{\"toothNumber\":12,\"surfaces\":{\"center\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:47:47.507Z\"},\"13\":{\"toothNumber\":13,\"surfaces\":{\"left\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:47:48.375Z\"},\"14\":{\"toothNumber\":14,\"surfaces\":{\"left\":\"caries\"},\"wholeToothCondition\":\"caries\",\"lastUpdated\":\"2026-09-24T16:47:48.971Z\"},\"15\":{\"toothNumber\":15,\"surfaces\":{\"left\":\"caries\",\"right\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:47:49.959Z\"},\"21\":{\"toothNumber\":21,\"surfaces\":{\"center\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:47:43.503Z\"},\"31\":{\"toothNumber\":31,\"surfaces\":{\"bottom\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:47:41.119Z\"},\"32\":{\"toothNumber\":32,\"surfaces\":{\"bottom\":\"caries\"},\"lastUpdated\":\"2026-09-24T16:47:42.051Z\"}}','healthy',NULL,70,'2026-09-24 16:47:49','2026-09-24 16:47:49'),(6,3,0,'{\"11\":{\"toothNumber\":11,\"surfaces\":{\"top\":\"caries\",\"bottom\":\"orthodontics\"},\"lastUpdated\":\"2026-09-22T18:05:38.113Z\"},\"12\":{\"toothNumber\":12,\"surfaces\":{\"right\":\"caries\"},\"lastUpdated\":\"2026-09-22T18:02:59.305Z\"},\"14\":{\"toothNumber\":14,\"surfaces\":{\"center\":\"orthodontics\"},\"lastUpdated\":\"2026-09-22T18:05:58.930Z\"},\"15\":{\"toothNumber\":15,\"surfaces\":[],\"wholeToothCondition\":\"implant\",\"lastUpdated\":\"2026-09-23T19:39:44.244Z\"},\"16\":{\"toothNumber\":16,\"surfaces\":[],\"wholeToothCondition\":\"absent\",\"lastUpdated\":\"2026-09-23T19:39:41.628Z\"},\"17\":{\"toothNumber\":17,\"surfaces\":[],\"wholeToothCondition\":\"extraction_needed\",\"lastUpdated\":\"2026-09-23T19:39:39.468Z\"},\"21\":{\"toothNumber\":21,\"surfaces\":{\"center\":\"caries\"},\"lastUpdated\":\"2026-09-22T17:48:11.840Z\"},\"22\":{\"toothNumber\":22,\"surfaces\":{\"top\":\"caries\"},\"lastUpdated\":\"2026-09-22T17:57:47.345Z\"},\"23\":{\"toothNumber\":23,\"surfaces\":{\"left\":\"caries\",\"right\":\"caries\",\"bottom\":\"implant\"},\"wholeToothCondition\":\"orthodontics\",\"notes\":\"En tracción con alineador\",\"lastUpdated\":\"2026-09-22T18:15:29.694Z\"},\"24\":{\"toothNumber\":24,\"surfaces\":{\"center\":\"caries\",\"top\":\"caries\"},\"lastUpdated\":\"2026-09-23T18:04:10.997Z\"},\"32\":{\"toothNumber\":32,\"surfaces\":{\"bottom\":\"caries\"},\"lastUpdated\":\"2026-09-22T20:22:43.792Z\"},\"33\":{\"toothNumber\":33,\"surfaces\":[],\"notes\":\"eeeee\",\"lastUpdated\":\"2026-09-22T20:22:25.831Z\"},\"34\":{\"toothNumber\":34,\"surfaces\":{\"center\":\"implant\"},\"lastUpdated\":\"2026-09-22T18:15:40.634Z\"},\"35\":{\"toothNumber\":35,\"surfaces\":{\"right\":\"caries\",\"center\":\"implant\"},\"lastUpdated\":\"2026-09-22T18:15:31.686Z\"},\"43\":{\"toothNumber\":43,\"surfaces\":{\"center\":\"caries\"},\"lastUpdated\":\"2026-09-22T05:41:29.914Z\"},\"44\":{\"toothNumber\":44,\"surfaces\":{\"center\":\"sealant\"}},\"47\":{\"toothNumber\":47,\"surfaces\":{\"bottom\":\"implant\"},\"lastUpdated\":\"2026-09-22T18:15:45.170Z\"}}','healthy',NULL,38,'2026-09-23 19:39:44','2026-09-23 19:39:44');
/*!40000 ALTER TABLE `odontogram_teeth` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-02 16:44:58
