-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_number` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guardian_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci DEFAULT 'other',
  `birth_date` date DEFAULT NULL,
  `birth_place` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'O+',
  `responsible_doctor_id` int DEFAULT NULL,
  `consultation_reason` text COLLATE utf8mb4_unicode_ci,
  `last_dental_visit` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observations` text COLLATE utf8mb4_unicode_ci,
  `consent_accepted` tinyint(1) NOT NULL DEFAULT '1',
  `consent_date` date DEFAULT NULL,
  `patient_signature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doctor_signature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allergies` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medical_conditions` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_medications` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_contact_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_contact_phone` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anamnesis_json` longtext COLLATE utf8mb4_unicode_ci,
  `stomatological_exam_json` longtext COLLATE utf8mb4_unicode_ci,
  `diagnosis_json` longtext COLLATE utf8mb4_unicode_ci,
  `treatment_plan_summary_json` json DEFAULT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `medicalhistory` longtext COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_number` (`id_number`),
  KEY `fk_patients_doctor` (`responsible_doctor_id`),
  CONSTRAINT `fk_patients_doctor` FOREIGN KEY (`responsible_doctor_id`) REFERENCES `doctors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Victor Hugo','Jimenez Torero','25750816','Sr','male','1972-12-07','Lima','Ingeniero','Pueblo Libre','992997872','vtorero@gmaiil.com','A-',1,NULL,NULL,NULL,1,NULL,NULL,'2','eeeeeeeee',NULL,NULL,'','',NULL,NULL,NULL,NULL,'','{\"hasDiabetes\":false,\"hasHypertension\":false,\"hasBleedingDisorders\":true,\"hasCardiacDisease\":false,\"isPregnant\":false,\"isSmoker\":false,\"currentMedications\":[],\"generalNotes\":\"\"}','2026-09-24 17:53:09','2026-09-17 20:40:10'),(2,'Michelle','Ledesma','40449657rrrrr','Srta','female','1980-09-02','Lima','Odontologa','La Molina','999691111111','','O-',2,NULL,NULL,NULL,1,NULL,NULL,'2','prueba,prueba 2',NULL,NULL,'','',NULL,NULL,NULL,NULL,'','{\"hasDiabetes\":false,\"hasHypertension\":false,\"hasBleedingDisorders\":false,\"hasCardiacDisease\":false,\"isPregnant\":false,\"isSmoker\":false,\"currentMedications\":[],\"generalNotes\":\"\"}','2026-09-30 22:52:44','2026-09-17 21:15:02'),(3,'test','test','32323eeee',NULL,'female','1995-01-01',NULL,'','Juan Antonio Arrieta 170wwwww','545545','vtorero@gmail.com','O+',2,NULL,NULL,NULL,1,NULL,NULL,'2','',NULL,NULL,'padre','99599874s',NULL,NULL,NULL,NULL,'','{\"hasDiabetes\":true,\"hasHypertension\":true,\"hasBleedingDisorders\":false,\"hasCardiacDisease\":false,\"isPregnant\":false,\"isSmoker\":true,\"currentMedications\":[],\"generalNotes\":\"\"}','2026-09-30 22:33:45','2026-09-19 05:23:46');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-02 16:44:59
