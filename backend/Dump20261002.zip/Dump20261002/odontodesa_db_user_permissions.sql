-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `is_granted` tinyint(1) NOT NULL DEFAULT '1',
  `granted_by` int DEFAULT NULL,
  `granted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_permission` (`user_id`,`permission_id`),
  KEY `fk_user_perm_perm` (`permission_id`),
  KEY `fk_user_perm_admin` (`granted_by`),
  CONSTRAINT `fk_user_perm_admin` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_user_perm_perm` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_perm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
INSERT INTO `user_permissions` VALUES (1,1,1,1,1,'2026-09-17 20:20:25'),(2,1,2,1,1,'2026-09-17 20:20:25'),(3,1,3,1,1,'2026-09-17 20:20:25'),(4,1,4,1,1,'2026-09-17 20:20:25'),(5,1,5,1,1,'2026-09-17 20:20:25'),(6,1,6,1,1,'2026-09-17 20:20:25'),(7,1,7,1,1,'2026-09-17 20:20:25'),(8,1,8,1,1,'2026-09-17 20:20:25'),(9,1,9,1,1,'2026-09-17 20:20:25'),(10,1,10,1,1,'2026-09-17 20:20:25'),(11,1,11,1,1,'2026-09-17 20:20:25'),(12,2,1,1,1,'2026-09-17 20:20:25'),(13,2,2,1,1,'2026-09-17 20:20:25'),(14,2,4,1,1,'2026-09-17 20:20:25'),(15,2,5,1,1,'2026-09-17 20:20:25'),(16,2,6,1,1,'2026-09-17 20:20:25'),(17,2,7,1,1,'2026-09-17 20:20:25'),(18,3,1,1,1,'2026-09-17 20:20:25'),(19,3,2,1,1,'2026-09-17 20:20:25'),(20,3,4,1,1,'2026-09-17 20:20:25'),(21,3,5,1,1,'2026-09-17 20:20:25'),(22,3,6,1,1,'2026-09-17 20:20:25'),(23,3,7,1,1,'2026-09-17 20:20:25'),(24,4,1,1,1,'2026-09-17 20:20:25'),(25,4,2,1,1,'2026-09-17 20:20:25'),(26,4,5,1,1,'2026-09-17 20:20:25'),(27,4,6,1,1,'2026-09-17 20:20:25'),(28,4,7,1,1,'2026-09-17 20:20:25'),(29,5,1,1,1,'2026-09-17 20:20:25'),(30,5,2,1,1,'2026-09-17 20:20:25'),(31,5,5,1,1,'2026-09-17 20:20:25'),(32,5,6,1,1,'2026-09-17 20:20:25'),(33,5,7,1,1,'2026-09-17 20:20:25'),(34,6,5,1,1,'2026-09-17 20:20:25'),(35,6,11,1,1,'2026-09-17 20:20:25');
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-02 16:44:59
