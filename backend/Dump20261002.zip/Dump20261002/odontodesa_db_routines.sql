-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `v_user_effective_permissions`
--

DROP TABLE IF EXISTS `v_user_effective_permissions`;
/*!50001 DROP VIEW IF EXISTS `v_user_effective_permissions`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_effective_permissions` AS SELECT 
 1 AS `user_id`,
 1 AS `username`,
 1 AS `user_role`,
 1 AS `role_id`,
 1 AS `role_name`,
 1 AS `permission_id`,
 1 AS `permission_code`,
 1 AS `permission_module`,
 1 AS `permission_name`,
 1 AS `is_effective_granted`,
 1 AS `permission_source`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_user_effective_permissions`
--

/*!50001 DROP VIEW IF EXISTS `v_user_effective_permissions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_effective_permissions` AS select `u`.`id` AS `user_id`,`u`.`username` AS `username`,`u`.`role` AS `user_role`,`r`.`id` AS `role_id`,`r`.`name` AS `role_name`,`p`.`id` AS `permission_id`,`p`.`code` AS `permission_code`,`p`.`module` AS `permission_module`,`p`.`name` AS `permission_name`,coalesce(`up`.`is_granted`,`rp`.`is_granted`,0) AS `is_effective_granted`,(case when (`up`.`is_granted` is not null) then 'USER_OVERRIDE' when (`rp`.`is_granted` is not null) then 'ROLE_DEFAULT' else 'DENIED_BY_DEFAULT' end) AS `permission_source` from ((((`users` `u` left join `roles` `r` on(((`u`.`role_id` = `r`.`id`) or (`u`.`role` = `r`.`slug`)))) join `permissions` `p`) left join `role_permissions` `rp` on(((`r`.`id` = `rp`.`role_id`) and (`p`.`id` = `rp`.`permission_id`)))) left join `user_permissions` `up` on(((`u`.`id` = `up`.`user_id`) and (`p`.`id` = `up`.`permission_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-02 16:45:00
