-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_perm_module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'canViewPatients','PACIENTES','Ver Pacientes & Odontograma','Permite consultar el listado y fichas clínicas de pacientes','2026-09-17 20:20:25'),(2,'canEditPatients','PACIENTES','Crear / Editar Ficha Clínica','Permite dar de alta pacientes y editar anamnesis y antecedentes','2026-09-17 20:20:25'),(3,'canDeletePatients','PACIENTES','Eliminar Pacientes','Permite eliminar pacientes de la base de datos','2026-09-17 20:20:25'),(4,'canEditOdontogram','ODONTOGRAMA','Modificar Piezas FDI en Odontograma','Permite marcar patologías, superficies y tratamientos en piezas dentales','2026-09-17 20:20:25'),(5,'canManageAppointments','CITAS','Agendar y Modificar Citas','Permite agendar, confirmar y reprogramar turnos en sillones dentales','2026-09-17 20:20:25'),(6,'canManageInventory','INVENTARIO','Control de Insumos y Kardex Dental','Permite registrar entradas, salidas y consultar stock de materiales','2026-09-17 20:20:25'),(7,'canManageBilling','FACTURACION','Facturación, Presupuestos y Cobros','Permite emitir facturas, registrar pagos y controlar saldos','2026-09-17 20:20:25'),(8,'canManageUsers','USUARIOS','Administración de Personal y Roles','Permite crear colaboradores, asignar roles y definir privilegios','2026-09-17 20:20:25'),(9,'canEditClinicSettings','CONFIGURACION','Configuración General de Clínica','Permite modificar datos de la clínica, sillones dentales y doctores','2026-09-17 20:20:25'),(10,'canViewAuditLogs','AUDITORIA','Visualizar Registros de Auditoría','Permite auditar accesos, inicios de sesión y cambios sensibles','2026-09-17 20:20:25'),(11,'canAccessPatientPortal','PORTAL','Acceso a Portal de Pacientes','Permite a pacientes consultar su plan, citas y recomendaciones','2026-09-17 20:20:25');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26 11:06:05
