-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `standard_treatment_catalog`
--

DROP TABLE IF EXISTS `standard_treatment_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `standard_treatment_catalog` (
  `item_number` int NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `is_orthodontics` tinyint(1) NOT NULL DEFAULT '0',
  `default_ortho_initial` decimal(10,2) DEFAULT NULL,
  `default_ortho_monthly` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`item_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard_treatment_catalog`
--

LOCK TABLES `standard_treatment_catalog` WRITE;
/*!40000 ALTER TABLE `standard_treatment_catalog` DISABLE KEYS */;
INSERT INTO `standard_treatment_catalog` VALUES (1,'Profilaxis y despistaje',80.00,0,NULL,NULL),(2,'Rx (Radiografía)',30.00,0,NULL,NULL),(3,'Blanqueamiento Dental',350.00,0,NULL,NULL),(4,'Exodoncia',90.00,0,NULL,NULL),(5,'Resina simple con luz halógena',70.00,0,NULL,NULL),(6,'Resina compuesta con luz halógena',110.00,0,NULL,NULL),(7,'Endodoncia anterior',220.00,0,NULL,NULL),(8,'Endodoncia posterior',320.00,0,NULL,NULL),(9,'P.P. Móviles',450.00,0,NULL,NULL),(10,'P. Completa',800.00,0,NULL,NULL),(11,'Ortodoncia',600.00,1,600.00,120.00),(12,'Perno Muñón',150.00,0,NULL,NULL),(13,'Corona Ivocron',250.00,0,NULL,NULL),(14,'Corona Metal Cerámica',420.00,0,NULL,NULL),(15,'Corona Libre de Metal',650.00,0,NULL,NULL),(16,'Fluorización',50.00,0,NULL,NULL),(17,'Gingivectomía / Gingivoplastia',180.00,0,NULL,NULL),(18,'Cirugía Diente Retenido / Semiretenido',380.00,0,NULL,NULL),(19,'Férula de descarga',280.00,0,NULL,NULL),(20,'Incrustación',260.00,0,NULL,NULL),(21,'Otros',0.00,0,NULL,NULL);
/*!40000 ALTER TABLE `standard_treatment_catalog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26 11:06:06
