-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient_medical_history`
--

DROP TABLE IF EXISTS `patient_medical_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_medical_history` (
  `patient_id` int NOT NULL,
  `under_treatment` tinyint(1) DEFAULT '0',
  `treatment_details` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_allergic_to_medication` tinyint(1) DEFAULT '0',
  `allergic_details` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `habitual_medications` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_cardiac_problems` tinyint(1) DEFAULT '0',
  `has_high_blood_pressure` tinyint(1) DEFAULT '0',
  `has_low_blood_pressure` tinyint(1) DEFAULT '0',
  `smokes` tinyint(1) DEFAULT '0',
  `drinks` tinyint(1) DEFAULT '0',
  `is_pregnant` tinyint(1) DEFAULT '0',
  `pregnancy_months` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enfermedades_venereas` tinyint(1) DEFAULT '0',
  `fiebre_reumatica` tinyint(1) DEFAULT '0',
  `hepatitis` tinyint(1) DEFAULT '0',
  `ulceras_estomago` tinyint(1) DEFAULT '0',
  `alteraciones_nerviosas` tinyint(1) DEFAULT '0',
  `sida` tinyint(1) DEFAULT '0',
  `epilepsia` tinyint(1) DEFAULT '0',
  `artritis` tinyint(1) DEFAULT '0',
  `cancer` tinyint(1) DEFAULT '0',
  `diabetes` tinyint(1) DEFAULT '0',
  `dolor_cabeza` tinyint(1) DEFAULT '0',
  `sinusitis` tinyint(1) DEFAULT '0',
  `otros` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_notes` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`patient_id`),
  CONSTRAINT `fk_medhistory_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_medical_history`
--

LOCK TABLES `patient_medical_history` WRITE;
/*!40000 ALTER TABLE `patient_medical_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_medical_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26 11:06:05
