-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: odontodesa_db
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_number` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int DEFAULT NULL,
  `role` enum('admin','doctor','assistant','patient') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assistant',
  `status` enum('active','inactive','suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `avatar_color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'bg-indigo-600 text-white',
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `shift` enum('morning','afternoon','full_time','weekend') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `associated_patient_id` int DEFAULT NULL,
  `permissions_json` json DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_role_id` (`role_id`),
  KEY `idx_users_patient` (`associated_patient_id`),
  CONSTRAINT `fk_users_role_rel` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin.elena','Elena','Ramos Morales','elena.ramos@odontosaludpro.com','+34 600 111 000','44556677A','$2y$10$abcdefghijklmnopqrstuvwxyz123456',1,'admin','active','bg-indigo-600 text-white',1,NULL,NULL,'{\"canManageUsers\": true, \"canEditPatients\": true, \"canViewPatients\": true, \"canManageBilling\": true, \"canViewAuditLogs\": true, \"canDeletePatients\": true, \"canEditOdontogram\": true, \"canManageInventory\": true, \"canEditClinicSettings\": true, \"canManageAppointments\": true, \"canAccessPatientPortal\": true}','2026-09-25 11:41:02','Directora Médica & Administradora General','2026-09-17 20:20:25','2026-09-25 16:41:02'),(2,'dr.carlos','Carlos','Mendoza','carlos.mendoza@odontosaludpro.com','+34 600 111 222','47889912B','$2y$10$abcdefghijklmnopqrstuvwxyz123456',2,'doctor','active','bg-sky-600 text-white',0,NULL,NULL,'{\"canManageUsers\": false, \"canEditPatients\": true, \"canViewPatients\": true, \"canManageBilling\": true, \"canViewAuditLogs\": false, \"canDeletePatients\": false, \"canEditOdontogram\": true, \"canManageInventory\": true, \"canEditClinicSettings\": false, \"canManageAppointments\": true, \"canAccessPatientPortal\": false}',NULL,'Especialista en Rehabilitación Oral','2026-09-17 20:20:25','2026-09-17 20:20:25'),(3,'dra.valeria','Valeria','Soto','valeria.soto@odontosaludpro.com','+34 600 333 444','51223344C','$2y$10$abcdefghijklmnopqrstuvwxyz123456',2,'doctor','active','bg-purple-600 text-white',1,NULL,NULL,'{\"canManageUsers\": false, \"canEditPatients\": true, \"canViewPatients\": true, \"canManageBilling\": true, \"canViewAuditLogs\": false, \"canDeletePatients\": false, \"canEditOdontogram\": true, \"canManageInventory\": true, \"canEditClinicSettings\": false, \"canManageAppointments\": true, \"canAccessPatientPortal\": false}',NULL,'Especialista en Ortodoncia','2026-09-17 20:20:25','2026-09-17 20:20:25'),(4,'asist.lucia','Lucía','Paredes Varga','lucia.paredes@odontosaludpro.com','+34 600 777 888','70889900D','$2y$10$abcdefghijklmnopqrstuvwxyz123456',3,'assistant','active','bg-amber-600 text-white',0,'morning',NULL,'{\"canManageUsers\": false, \"canEditPatients\": true, \"canViewPatients\": true, \"canManageBilling\": true, \"canViewAuditLogs\": false, \"canDeletePatients\": false, \"canEditOdontogram\": false, \"canManageInventory\": true, \"canEditClinicSettings\": false, \"canManageAppointments\": true, \"canAccessPatientPortal\": false}',NULL,'Recepción y triaje','2026-09-17 20:20:25','2026-09-17 20:20:25'),(5,'asist.mateo','Mateo','Gómez Castro','mateo.gomez@odontosaludpro.com','+34 600 999 111','72334455E','$2y$10$abcdefghijklmnopqrstuvwxyz123456',3,'assistant','active','bg-emerald-600 text-white',0,'afternoon',NULL,'{\"canManageUsers\": false, \"canEditPatients\": true, \"canViewPatients\": true, \"canManageBilling\": true, \"canViewAuditLogs\": false, \"canDeletePatients\": false, \"canEditOdontogram\": false, \"canManageInventory\": true, \"canEditClinicSettings\": false, \"canManageAppointments\": true, \"canAccessPatientPortal\": false}',NULL,'Asistente de gabinete e insumos','2026-09-17 20:20:25','2026-09-17 20:20:25'),(6,'paciente.sofia','Sofía','Alarcón Benítez','sofia.alarcon@email.com','+34 612 345 678','48990011K','$2y$10$abcdefghijklmnopqrstuvwxyz123456',4,'patient','active','bg-teal-600 text-white',0,NULL,1,'{\"canManageUsers\": false, \"canEditPatients\": false, \"canViewPatients\": false, \"canManageBilling\": false, \"canViewAuditLogs\": false, \"canDeletePatients\": false, \"canEditOdontogram\": false, \"canManageInventory\": false, \"canEditClinicSettings\": false, \"canManageAppointments\": true, \"canAccessPatientPortal\": true}',NULL,'Paciente con acceso a portal clínico','2026-09-17 20:20:25','2026-09-17 20:20:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-26 11:06:06
